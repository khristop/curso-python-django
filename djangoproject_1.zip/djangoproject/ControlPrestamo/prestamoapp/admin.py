from django.contrib import admin
from prestamoapp.models import Articulo,Carrera,Prestamo,Estudiante


class PrestamoAdmin(admin.ModelAdmin):
    list_display=('articulo','estudiante','fechaPrestamo','fechaEntrega')

admin.site.register(Articulo)
admin.site.register(Carrera)
admin.site.register(Estudiante)
admin.site.register(Prestamo,PrestamoAdmin)

# Register your models here.

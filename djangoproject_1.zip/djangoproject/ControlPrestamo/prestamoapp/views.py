from django.shortcuts import render
from django.http import HttpResponse
from django.template.context_processors import request
from prestamoapp.models import Articulo

# Create your views here.

def mi_primer_vista(request):
    return HttpResponse('bienvernido al curso de python  y django')

def misArticulos(request):
    return render(request,'mis_articulos.html',{'articulos':Articulo.objects.all()})
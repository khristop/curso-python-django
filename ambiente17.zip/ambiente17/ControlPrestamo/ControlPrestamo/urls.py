from django.conf.urls import patterns, include, url
from django.contrib import admin
from prestamoapp.views import misArticulos,probando,ListPrestamoView,ListArticuloView
from prestamoapp.views import CreateArticuloView,DetailArticulo
from prestamoapp.views import DeleteArticulo,UpdateArticuloView

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'ControlPrestamo.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^primeravista/$','prestamoapp.views.mi_primer_vista'),
    url(r'^articulos/$',misArticulos),
    url(r'^prueba/$',probando),
    url(r'^$',ListArticuloView.as_view(),name="articulo-list",),
    url(r'^newArticulo/$',CreateArticuloView.as_view(),name="articulo-new",),
    url(r'^prestamos/$',ListPrestamoView.as_view(),name="prestamo-list",),
    url(r'^(?P<pk>\w+)/$',DetailArticulo.as_view(),name='articulo-view' ,),
    url(r'^delete/(?P<pk>\w+)/$',DeleteArticulo.as_view() ,name='articulo-delete',),
    url(r'^update/(?P<pk>\w+)/$',UpdateArticuloView.as_view() ,name='articulo-edit',),


)

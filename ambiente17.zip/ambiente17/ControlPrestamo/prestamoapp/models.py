from django.db import models
from django.utils import timezone
from django.core.urlresolvers import reverse
# Create your models here.

class Carrera(models.Model):
    codigo=models.CharField(max_length=6,primary_key=True)
    nombreCarrera = models.CharField(max_length=100,null=False)

    def __str__(self):
        return self.nombreCarrera

class Articulo(models.Model):
    codigoArticulo=models.CharField(max_length=6,primary_key=True)
    nombreArticulo=models.CharField(max_length=100,null=False)
    descripcion = models.CharField(max_length=255)
    prestado = models.BooleanField(default=False)
    def get_absolute_url(self):
        return reverse('articulo-view',kwargs={'pk':self.codigoArticulo})


    def __str__(self):
        return self.nombreArticulo

class Estudiante(models.Model):
    carnet=models.CharField(max_length=7,primary_key=True)
    carrera=models.ForeignKey(Carrera,null=False)
    nombre=models.CharField(max_length=30,null=False)
    apellido=models.CharField(max_length=30,null=False)

    def __str__(self):
        return self.nombre

class Prestamo(models.Model):
    articulo = models.OneToOneField(Articulo,null=False,)
    estudiante=models.ForeignKey(Estudiante,null=False)
    fechaPrestamo=models.DateField(auto_now_add=timezone.now().date())
    fechaEntrega=models.DateField()

    def __str__(self):
        return self.estudiante.nombre+" ha prestado "+self.articulo.nombreArticulo






from django.shortcuts import render
from django.core.urlresolvers import reverse

from django.http import HttpResponse
#from prestamoapp.models import Articulo
from django.views.generic import ListView,CreateView
from prestamoapp.models import Prestamo,Articulo
from prestamoapp.forms import ArticuloForm
from django.views.generic import DetailView,DeleteView
from django.views.generic import UpdateView

def mi_primer_vista(request):
    return HttpResponse("Bienvenido al curso de python y django")

def misArticulos(request):
    return render(request,'mis_articulos.html',{'articulos':Articulo.objects.all()})

def probando(request):
    return render(request,"prestamo.html")

class ListArticuloView(ListView):
    model = Articulo
    template_name = "articulo_list.html"

class ListPrestamoView(ListView):
    model = Prestamo
    template_name = "prestamo_list.html"

class CreateArticuloView(CreateView):
    model = Articulo
    template_name = 'edit_articulo.html'
    form_class = ArticuloForm

    def get_context_data(self, **kwargs):
        context=super(CreateArticuloView,self).get_context_data(**kwargs)
        context['action']=reverse('articulo-new')
        return context

    def get_success_url(self):
        return reverse('articulo-list')

class DetailArticulo(DetailView):
    model = Articulo
    template_name = 'detalle_articulo.html'

class DeleteArticulo(DeleteView):
    model = Articulo
    template_name = 'delete_articulo.html'
    def get_success_url(self):
        return reverse('articulo-list')

class UpdateArticuloView(UpdateView):
    model = Articulo
    template_name = 'edit_articulo.html'
    form_class = ArticuloForm
    def get_context_data(self, **kwargs):
        context=super(UpdateArticuloView,self).get_context_data(**kwargs)
        context['action']=reverse('articulo-edit',kwargs={'pk':self.get_object().codigoArticulo})
        return context

    def get_success_url(self):
        return  reverse('articulo-list')

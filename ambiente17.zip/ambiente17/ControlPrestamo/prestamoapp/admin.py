from django.contrib import admin
from prestamoapp.models import Estudiante,Prestamo,Articulo,Carrera


# Register your models here.

class EstuduanteAdmin(admin.ModelAdmin):
    list_display = ('carnet','nombre','carrera')#tupla

class PrestamoAdmin(admin.ModelAdmin):
    list_display = ('articulo','estudiante','fechaPrestamo','fechaEntrega')

class ArticuloAdmin(admin.ModelAdmin):
    list_display = ('codigoArticulo','nombreArticulo','descripcion','prestado')

class CarreraAdmin(admin.ModelAdmin):
    list_display = ('codigo','nombreCarrera')

admin.site.register(Articulo,ArticuloAdmin)
admin.site.register(Carrera,CarreraAdmin)
admin.site.register(Estudiante,EstuduanteAdmin)
admin.site.register(Prestamo,PrestamoAdmin)

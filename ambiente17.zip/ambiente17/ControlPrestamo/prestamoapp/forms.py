
from django import forms
from django.core.exceptions import ValidationError
from prestamoapp.models import Articulo
import re

class ArticuloForm(forms.ModelForm):

    #Personalizamos los campos
    codigoArticulo=forms.CharField(max_length=6,required=True,label="Codigo",help_text="Codigo de Articulo")
    nombreArticulo=forms.CharField(max_length=100,required=True,label="Nombre")
    descripcion = forms.CharField(max_length=255,required=True,label="Descripcion")
    prestado = forms.BooleanField(label="Prestado",required=False)

    class Meta:
        model = Articulo

    def clean_codigoArticulo(self):
        #Capturamos el valor de codigo Artiiculo
        codigoArticulo= self.cleaned_data.get('codigoArticulo')

        #Comparamos que no tenga menos de 6 caracteres
        if len(codigoArticulo)<6:
            raise forms.ValidationError("Debe tener 6 caracteres")
        elif (re.match("[a-zA-z][a-zA-z]\d\d\d\d",codigoArticulo)) == None:
            #Validamos que las 2 primeros caracteres sean letras y 4 numeros
            raise forms.ValidationError("error: debe ser dos caracteres seguido de 4 numeros")

        return codigoArticulo
    #Validamos que el nombre empiece con un caracter y luego se alfanumerico
    # A-Z,a-z,0-9
    def clean_nombreArticulo(self):
        nombreArticulo = self.cleaned_data.get('nombreArticulo')
        #Expresion regular a-zA-Z], comprueba que el primer caracter sea una letra
        if(re.match("[a-zA-Z]",nombreArticulo)==None):
            raise forms.ValidationError("Debe iniciar con un caracter")
        # "\w*" verifica que todos los caracteres sean alfanumericos
        # \w es lo mismo que [a-z0-9-A-Z]
        elif (re.match("\w*",nombreArticulo)) ==None:
            raise forms.ValidationError("Deben de ser caracters alfanumerico")
        return nombreArticulo


    #validamos que la descripcion del articulo no sea menor que 4
    def clean_descripcion(self):
        descripcion = self.cleaned_data.get('descripcion')
        num_words = len(descripcion.split())
        if num_words < 4:
            raise forms.ValidationError("Deben de ser minimo 4 palabras!")
        return descripcion





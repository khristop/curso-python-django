# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Articulo',
            fields=[
                ('codigoArticulo', models.CharField(primary_key=True, serialize=False, max_length=6)),
                ('nombreArticulo', models.CharField(max_length=100)),
                ('descripcion', models.CharField(max_length=255)),
                ('prestado', models.BooleanField(default=False)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Carrera',
            fields=[
                ('codigo', models.CharField(primary_key=True, serialize=False, max_length=6)),
                ('nombreCarrera', models.CharField(max_length=100)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Estudiante',
            fields=[
                ('carnet', models.CharField(primary_key=True, serialize=False, max_length=7)),
                ('nombre', models.CharField(max_length=30)),
                ('apellido', models.CharField(max_length=30)),
                ('carrera', models.ForeignKey(to='prestamoapp.Carrera')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Prestamo',
            fields=[
                ('id', models.AutoField(primary_key=True, verbose_name='ID', serialize=False, auto_created=True)),
                ('fechaPrestamo', models.DateField(auto_now_add=True)),
                ('fechaEntrega', models.DateField()),
                ('articulo', models.OneToOneField(to='prestamoapp.Articulo')),
                ('estudiante', models.ForeignKey(to='prestamoapp.Estudiante')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]

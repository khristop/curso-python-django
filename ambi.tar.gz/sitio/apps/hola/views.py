from django.shortcuts import render, render_to_response
from django.template.context_processors import request
from django.http.response import HttpResponse

# Create your views here.
def holaMundo(request):
    #return HttpResponse('Hola mundo, Esta es la pagina principal')
    template = "base.html"
    return render_to_response(template,{})

def sub(request):
    return HttpResponse("Pagina sub")
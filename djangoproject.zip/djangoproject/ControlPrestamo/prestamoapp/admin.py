from django.contrib import admin
from prestamoapp.models import Articulo,Carrera,Prestamo,Estudiante

admin.site.register(Articulo)
admin.site.register(Carrera)
admin.site.register(Estudiante)
admin.site.register(Prestamo)

# Register your models here.

from django.shortcuts import render

from django.http import HttpResponse

def mi_primer_vista(request):
    return HttpResponse("Bienvenido al curso de python y django")
